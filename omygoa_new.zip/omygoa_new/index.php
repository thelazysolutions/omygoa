
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Meta -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="Anil z" name="author">
<meta name="viewport" content="width=device-width, initial-scale=1">


<!-- SITE TITLE -->
<title>Goa</title>

<!-- Latest Bootstrap min CSS -->
<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
<!-- Icon Font CSS -->
<link rel="stylesheet" href="assets/css/themify-icons.css">
<!-- Icon Font CSS -->
<link rel="stylesheet" href="assets/css/ionicons.min.css">
<!--- owl carousel CSS-->
<link rel="stylesheet" href="assets/owlcarousel/css/owl.carousel.min.css">
<link rel="stylesheet" href="assets/owlcarousel/css/owl.theme.css">
<link rel="stylesheet" href="assets/owlcarousel/css/owl.theme.default.min.css">
<!-- Style CSS -->
<link rel="stylesheet" href="assets/css/style.css">
<!-- Style CSS -->
<link rel="stylesheet" href="assets/css/responsive.css">
</head>

<body data-spy="scroll" data-target=".navbar-nav" data-offset="110">

 

<!-- START HEADER -->
<header class="header_wrap fixed-top light_skin hover_menu_style2 transparent-header bg_color">
  <div class="container-fluid">
    <nav class="navbar navbar-expand-lg"> 
    	<a class="navbar-brand page-scroll" href="#home_section">
            <h2>Logo</h2>
        	<!--<img class="logo_light" src="assets/images/logo_white.png" alt="logo" />
            <img class="logo_dark" src="assets/images/logo_dark.png" alt="logo" />
            <img class="logo_default" src="assets/images/logo_dark.png" alt="logo" />-->
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span class="ion-android-menu"></span> </button>
      	<div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
            <ul class="navbar-nav header_list">
                <li>
                    <a class="nav-link active page-scroll header_link" href="#">Products</a>
                </li>
                <li>
                    <a class="nav-link  header_link" href="#">Services</a>
                </li>
                <li>
                    <a class="nav-link  header_link" href="#">Events</a>
                </li>
                
                <li>
                    <a class="nav-link  header_link" href="#">Offers</a>
                </li>
                <li>
                    <a class="nav-link  header_link" href="#">Government Offices/ <br>Institutions</a>
                </li>
                <li>
                    <a class="nav-link" href="#">Non Government Organisations/ <br> Institutions</a>
                </li>
               
            </ul>
        <ul class="navbar-nav attr-nav align-items-center">
            <li>
                <a href="#" 
                style="background: #e60e90;padding: 8px 24px;border-radius: 3px;position: relative;top:7px;color:#fff;font-size:14px;">
                Add Listing</a><br> 
<a href="#" style="background: #19acc3;padding: 6px 13px;color: #fff;border-radius: 3px;position: relative;top:17px;color:#fff;font-size:14px;
">Sign Up / Login</a>
            </li>
                <li>
                   <div style="background-image: linear-gradient(#9c1212, #080808);width:137px;border-radius: 5px;min-height: 100px;">
                       <p class="text-center text-white" style="padding-top:5px;">Goa Places</p>
                       <p class="text-center text-white"><i class="ion-skip-backward"></i>  <i class="ion-play"></i> <i class="ion-skip-forward"></i></p>
                   </div>
                </li>
               
            </ul>
        </div>
    </nav>
  </div>
 
  <div class="bottom-header desktop_display" style="background:#19acc3;box-shadow: 0 0 10px rgb(0 0 0 / 15%);">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 col-sm-8 text-center">
                <form method="post" style="padding-top:20px;">
                    <div class="row justify-content-center">
                        <div class="form-group col-lg-3" style="margin-bottom:0px;">
                            <input required="required" placeholder="Quick Search" id="first-name" class="form-control" name="name" type="text">
                         </div>
                        <div class="form-group col-lg-4" style="margin-bottom:0px;">
                        <div class="input-group mb-2">
                        <div class="custom_select">
                                    <select class="form-control not_chosen">
                                        <option value="">Location</option>
                                        <option value="1">All Events</option>
                                        <option value="2">Wedding Ceremony</option>
                                        <option value="3">Reception Party</option>
                                        
                                    </select>
                                </div>
                                    <a href="#">
                                    <div class="input-group-prepend">
                                    <div class="input-group-text" style="background: #08616f;color:#fff;border: none;">
                                    <div style="width:30px;"><i class="ion-ios-search-strong" style="font-size:18px;"></i></div></div>
                                    </div>
                                  </a>
                                </div>
                        </div>
                        
                    </div>
                </form>
            </div>
            </div>
    </div>
</div>
</header>
<!-- START HEADER --> 


<section id="home_section" class="banner_section background_bg overlay_bg full_screen" style="background: url('assets/images/bg_image.jpg')center center / cover;">
    <div class="banner_slide_content">
       <div class="container-fluid">
            <!--<div class="row" style="position: relative;top:-55px;">
                <div class="col-xl-12 col-lg-12 col-sm-12 text-left" style="background:#19acc3;">
                    <form method="post" style="padding-top:20px;">
                        <div class="row justify-content-center">
                            <div class="form-group col-lg-3">
                                <input required="required" placeholder="Quick Search" id="first-name" class="form-control" name="name" type="text">
                             </div>
                            <div class="form-group col-lg-4">
                                <div class="custom_select">
                                    <select class="form-control not_chosen">
                                        <option value="">Location</option>
                                        <option value="1">All Events</option>
                                        <option value="2">Wedding Ceremony</option>
                                        <option value="3">Reception Party</option>
                                        
                                    </select>
                                </div>
                            </div>
                            <div class="form-group col-lg-1">
                                <div class="form-group col-lg-1">
                                    <button type="button" class="btn btn-primary mb-2"><i class="ion-ios-search-strong"></i></button>
                                </div>
                        </div>
                            <div class="col-lg-12 text-center">
                                <div id="alert-msg" class="alert-msg text-center"></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>-->
            <div class="row">
                <div class="col-xl-8 col-lg-12 col-sm-12 text-left">
                    <div class="banner_content text-white" style="padding-top:40px;">
                        <h2 style="font-size: 52px;color:#fff;">Turbulebt times </h2>
                        <p style="color:#fff;">Global marketing.</p>
                    </div>
                </div>
            </div>
        </div><!-- END CONTAINER-->
    </div>
</section>



<section class="background_bg pt-0"  style="margin-top:150px; background: url(assets/images/watercolor.png) no-repeat center center; 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 col-md-12 col-sm-6 text-center"> 
                <div class="mt-4 mt-lg-0">
                    <img src="assets/images/leaves-3.png" alt="aboutimg" style="max-width: 841px;position: relative;left: 35px;top:-43px;z-index: 2;">
                </div>
            </div>
        </div>
         <div class="row justify-content-center">
            <div class="col-lg-6 col-md-12 col-sm-12 text-center"> 
                <div class="mt-4 mt-lg-0">
                    <img src="assets/images/bamboo.png"   alt="aboutimg" style="max-width:50px;position: absolute;top:-115px;left:238px;"> 
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 text-center"> 
                <div class="mt-4 mt-lg-0">
                    <img src="assets/images/bamboo.png"  alt="aboutimg" style="max-width:50px;position: absolute;top:-115px;"> 
                </div>
            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-lg-6 col-md-12 col-sm-12 text-center" style="position:relative;top:-74px;background-image: url('assets/images/board.png');background-size: cover;padding:41px 0px;">
                <div class="text-center"> 
                    <h1 style="font-size: 44px;font-weight: 800;color: #000;">FEATURED LISTING</h1>
                </div>
                </div>
        </div>
         <div class="row justify-content-center">
            <div class="col-lg-8 col-md-8 col-sm-6 text-center">
                <ul class="portfolio_gallery portfolio_style4 carousel_slide3 owl-carousel owl-theme" data-margin="15" data-dots="false" data-autoplay="true" data-nav="true" data-loop="true" data-autoplay-timeout="2500" style="background-image:linear-gradient(#eefd009e, #c5bb3d);list-style-type:none;padding:10px;position:relative;top:-50px;">
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                               
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                </ul>
            </div>
            
        </div>
    </div>
</section>

<section class="background_bg" class="background_bg" style="margin-top:150px;height:120vh; background: url(assets/images/watercolor.png) no-repeat center center; 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-12 col-sm-12"> 
                <div class="mt-4 mt-lg-0" style="position: relative;top:-226px;">
                    <img src="assets/images/coconut.png" alt="aboutimg" style="max-width:377px;"> 
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-6 text-center" data-animation="fadeInUp" data-animation-delay="0.1s" style="animation-delay: 0.1s; opacity: 1;">
                <div class="text-center"> 
                  <h2 style="font-size: 44px;font-weight: 600;position:relative;top:-160px">TRENDING SERVICES</h2>
                </div>
                <ul class="portfolio_gallery portfolio_style4 carousel_slide3 owl-carousel owl-theme" data-margin="15" data-dots="false" data-autoplay="true" data-nav="true" data-loop="true" data-autoplay-timeout="2500" style="position:relative;top:-153px;background-image:linear-gradient(#eefd009e, #c5bb3d);padding:10px;list-style-type:none;">
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                    	<div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                    	<div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                               
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                </ul>
            </div>
            
        </div>
    </div>
</section>


<section class="background_bg pt-0" style="position: relative;top:-199px;">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-6  col-md-7 col-sm-6" data-animation="fadeInUp" data-animation-delay="0.1s" style="animation-delay: 0.1s; opacity: 1;">
                <div class="text-center"> 
                  <h2 style="font-size: 44px;font-weight: 600;">TRENDING PRODUCTS</h2>
                </div>
                <ul class="portfolio_gallery portfolio_style4 carousel_slide3 owl-carousel owl-theme" data-margin="15" data-dots="false" data-autoplay="true" data-nav="true" data-loop="true" data-autoplay-timeout="2500" style="list-style-type:none;background-image:linear-gradient(#eefd009e, #c5bb3d);padding:10px;">
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                    	<div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                    	<div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                            </a>
                               
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                </ul>
            </div>
            <div class="col-lg-6  col-md-4 col-sm-4 text-left"> 
                <div class="mt-4 mt-lg-0">
                    <img src="assets/images/people_fish2.png" class=" img_style" alt="aboutimg">
                </div>
            </div>
        </div>
    </div>
</section>

<section class="background_bg pt-0" style=" position:relative;top:-250px;background: url(assets/images/watercolor.png) no-repeat center center; 
-webkit-background-size: cover;
-moz-background-size: cover;
-o-background-size: cover;
background-size: cover;">
    <div class="container-fluid">
         <div class="row">
            <div class="col-lg-4 col-md-12 col-sm-12"> 
            <div class="mt-4 mt-lg-0">
                <img src="assets/images/bg_people.png"  alt="aboutimg" style="max-width: 710px;position: relative;right: 137px;">
            </div>desk
        </div>
            <div class="col-lg-7  col-md-7 col-sm-6">
            <div class="text-center"> 
                  <h2 style="font-size: 44px;font-weight: 600;position:relative;top:200px;">TRENDING EVENTS</h2>
                </div>
                <ul class="portfolio_gallery portfolio_style4 carousel_slide3 owl-carousel owl-theme" data-margin="15" data-dots="false" data-autoplay="true" data-nav="true" data-loop="true" data-autoplay-timeout="2500" style="list-style-type:none;background-image:linear-gradient(#eefd009e, #c5bb3d);padding:10px;position: relative;top:200px;">
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image" style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                        <a href="#" class="image_link">
                            <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                        </a>
                            
                    </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                                
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                    <!-- START PORTFOLIO ITEM -->
                    <li class="portfolio-item">
                        <div class="portfolio_item">
                            <a href="#" class="image_link">
                                <img src="assets/images/doctor.jpg" alt="image"  style="border:3px solid #fff;">
                            </a>
                               
                        </div>
                    </li>
                    <!-- END PORTFOLIO ITEM -->
                </ul>
            </div>
            
        </div>
    </div>
</section>

<section class="small_pb overflow_hide pt-0">
    <div class="container">
        <div class="row align-items-center"  style="position: relative;top:-200px;">
        	<div class="col-md-6 col-sm-12 mb-4 mb-lg-0">
            	<div>
            		<img src="assets/images/laptop.jpg" alt="about_img6">
                </div>
            </div>
            <div class="col-md-6 col-sm-12 animation animated fadeInRight" data-animation="fadeInRight" data-animation-delay="0.4s" style="animation-delay: 0.4s; opacity: 1;">
                <div class="heading_s3 mb-3"> 
                 
                  <h1>Looking for the best service provider ? <span style="font-weight: 800;">Get the link</span></h1>
                </div>
                <div class="color_blue">
                    <ul style="list-style-type:none;" class="text-center">
                        <li>  <h6> <span style="font-size:40px;color:#19acc3;"> &#8250; </span> Tell us more about your requirements </h6></li>
                        <li>  <h6 style="line-height:20px;"> <span style="font-size:40px;color:#19acc3;"> &#8250; </span> Tell us more about your requirements </h6></li>
                        <li>  <h6 style="line-height:20px;"> <span style="font-size:40px;color:#19acc3;"> &#8250; </span> Tell us more about your requirements </h6></li>
                        <li>  <h6 style="line-height:20px;"> <span style="font-size:40px;color:#19acc3;"> &#8250; </span> Tell us more about your requirements </h6></li>
                    </ul>
                </div>
                <p style="padding-top:20px;">We’ll send you a link to you below provided email id & open it on your smart phone to download the app</p>
                
                          <div class="input-group mb-2">
                                    <input type="email" class="form-control" id="inlineFormInputGroup" placeholder="Email">
                                    <a href="#">
                                    <div class="input-group-prepend">
                                      <div class="input-group-text" style="background:#e60e90;color:#fff;">Get the link</div>
                                    </div>
                                  </a>
                                </div>
                                 
            </div>
        </div>
        <div class="row align-items-center"  style="position: relative;top:-100px;">
        	<div class="col-md-6 col-sm-12 mb-4 mb-lg-0">
                <h1>What Services do you need</h1>
                <h1 style="color:#e60e90;">BizBook Directory</h1>
                <p>If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text</p>
                <div class=" color_blue">
                    <ul style="list-style-type:none;">
                    <li>  <h4 style="color:#19acc3;font-weight:700"><span> <i class="ion-ios-arrow-forward" style="color:#19acc3;font-size:30px;"></i></span> Tell us more about your requirements </h4></li>
                        <p>If you are going to use a passage of Lorem Ipsum,</p>
                        <li>  <h4 style="color:#19acc3;font-weight:700"><span> <i class="ion-ios-arrow-forward" style="color:#19acc3;font-size:30px;"></i></span> Tell us more about your requirements </h4></li></li>
                        <p>If you are going to use a passage of Lorem Ipsum,</p>
                        <li>  <h4 style="color:#19acc3;font-weight:700"><span> <i class="ion-ios-arrow-forward" style="color:#19acc3;font-size:30px;"></i></span> Tell us more about your requirements </h4></li></li>
                        <p>If you are going to use a passage of Lorem Ipsum,</p>
                        <li>  <h4 style="color:#19acc3;font-weight:700"><span> <i class="ion-ios-arrow-forward" style="color:#19acc3;font-size:30px;"></i></span> Tell us more about your requirements </h4></li></li>
                        <p>If you are going to use a passage of Lorem Ipsum,</p>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-12 animation animated fadeInRight" data-animation="fadeInRight" data-animation-delay="0.4s" style="animation-delay: 0.4s; opacity: 1;">
            <div class="col-md-12 col-sm-12" style="background: #25668c;height: 27px;">
                </div>
            <div class="field_form" style="box-shadow: 2px 2px 9px rgb(8 54 66 / 77%);padding: 10px 35px;">
           
                    <form method="post">
                    <div class="row justify-content-center">
                        <div  style="padding:17px;"><h2 class="text-center" style="font-weight:700">What you looking for ?</h2></div>
                        <div class="form-group col-lg-12">
                            <input required="required" placeholder="Full Name  *" class="form-control" name="name" type="text" style="background:#d9edf1;">
                         </div>
                        <div class="form-group col-lg-12">
                            <input required="required" placeholder=" Email *" class="form-control" name="email" type="email" style="background:#d9edf1;">
                        </div>
                        <div class="form-group col-lg-12">
                       
                            <input required="required" placeholder="Phone No. *" class="form-control" name="phone" type="phone" style="background:#d9edf1;">
                        </div>
                        <div class="form-group col-lg-12">
                        <div class="custom_select">
                                    <select class="form-control not_chosen" style="background:#d9edf1;">
                                        <option value="">Select Category</option>
                                        <option value="1">All Events</option>
                                        <option value="2">Wedding Ceremony</option>
                                        <option value="3">Reception Party</option>
                                        
                                    </select>
                                </div>
                        </div>
                        <div class="form-group col-lg-12">
                       
                            <textarea required="required" placeholder="Enter yor Query or Message" class="form-control" name="message" rows="4" style="background:#d9edf1;"></textarea>
                        </div>
                        <div class="col-lg-12 text-center">
                            <button type="button" class="btn btn-secondary btn-radius mb-2" style=" background-color: #e60e90;border:none;">Submit your requirement</button>
                        </div>
                        
                    </div>
                </form>		
                </div>
                   
        </div>
    </div>
    <div class="container">
    	<div class="row" style="padding-top:50px;">
        	<div class="col-md-12 animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.2s" style="animation-delay: 0.2s; opacity: 1;">
            	<div class="heading_s3 text-center">
                
                	
                </div>
            </div>
        </div>
    </div>
</section>
<footer style="background:#19859a;"> 
	<div class="top_footer text_white">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
                <h6 class="widget_title text-white">Top Category</h6>
                <ul class="list_none widget_links_style1">
                  
                  </ul>
                   
                </div>
                <div class="col-lg-4 col-md-6 mt-4 mt-lg-0 animation animated fadeInUp" data-animation="fadeInUp" data-animation-delay="0.2s" style="animation-delay: 0.2s; opacity: 1;">
                	<h6 class="widget_title text-white">Trending Category</h6>
                    <ul class="list_none widget_links_style1">
                  
                </ul>
                </div>
                <div class="col-lg-4 col-md-6 mb-4 mb-lg-0">
                <h6 class="widget_title text-white">Help & Support</h6>
                <ul class="list_none widget_links_style1">
                  
                  </ul>
                </div>
                
            </div>
        </div>
    </div>
    <hr>
    <div class="bottom_footer text_white"  style="background:#19859a;">
    	<div class="container">
        	<div class="row justify-content-center">
            	<div class="col-md-6 text-center">
                <p class="text-white"></p>
                </div>
               
            </div>
        </div>
    </div>
</footer>

<!-- Latest jQuery --> 
<script src="assets/js/jquery-1.12.4.min.js"></script> 
<!-- jquery-ui --> 
<script src="assets/js/jquery-ui.js"></script>

<!-- Latest compiled and minified Bootstrap --> 
<script src="assets/bootstrap/js/bootstrap.min.js"></script> 
<!-- owl-carousel min js  --> 
<script src="assets/owlcarousel/js/owl.carousel.min.js"></script> 

<script src="assets/js/scripts.js"></script>

</body>
</html>